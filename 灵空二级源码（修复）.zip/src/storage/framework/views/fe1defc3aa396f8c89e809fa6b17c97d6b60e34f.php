<center>
    <h1>会员激活认证</h1>
    <p style="font-size: 12px;color: grey">
        <?php echo e($username); ?>，您好！感谢你注册<?php echo e($webName); ?>，请点击下面链接完成激活认证你的账户。<br>
        <a href="<?php echo e($url); ?>"><?php echo e($url); ?></a>
    </p>
</center><?php /**PATH /home/ftp/s/ser177390476772/ym/src/resources/views/email/verify.blade.php ENDPATH**/ ?>